<?php

/**
 * Created by PhpStorm.
 * User: sashapc
 * Date: 10.08.2017
 * Time: 18:45
 */
class m150318_154933_gallery_ext
    extends zxbodya\yii2\galleryManager\migrations\m140930_003227_gallery_manager
{

}